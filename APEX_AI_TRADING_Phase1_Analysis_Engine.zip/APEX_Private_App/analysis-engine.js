/* APEX AI Analysis Engine v0.1 — deterministic rules, not a trained ML model. */
(function (root) {
  'use strict';
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const mean=a=>a.length?a.reduce((s,x)=>s+x,0)/a.length:null;
  function ema(values, period){ if(values.length<period) return null; const k=2/(period+1); let e=mean(values.slice(0,period)); for(let i=period;i<values.length;i++) e=values[i]*k+e*(1-k); return e; }
  function rsi(values, period=14){ if(values.length<period+1)return null; let up=0,down=0; for(let i=values.length-period;i<values.length;i++){const d=values[i]-values[i-1]; if(d>0)up+=d;else down-=d;} if(!down)return 100; return 100-100/(1+(up/period)/(down/period)); }
  function atr(candles, period=14){ if(candles.length<period+1)return null; const tr=[]; for(let i=1;i<candles.length;i++){const c=candles[i],p=candles[i-1];tr.push(Math.max(c.high-c.low,Math.abs(c.high-p.close),Math.abs(c.low-p.close)));} return mean(tr.slice(-period)); }
  function analyze(candles, symbol='BTCUSDT', timeframe='1m'){
    if(!Array.isArray(candles)||candles.length<30) return {symbol,timeframe,status:'INSUFFICIENT_DATA',decision:'WAIT',reason:'ต้องมีแท่งราคาอย่างน้อย 30 แท่ง',score:0};
    const closes=candles.map(x=>Number(x.close)), last=candles[candles.length-1], e20=ema(closes,20),e50=ema(closes,50),r=rsi(closes),a=atr(candles);
    if(e20===null||e50===null||r===null||a===null)return {symbol,timeframe,status:'INSUFFICIENT_DATA',decision:'WAIT',reason:'ข้อมูลยังไม่พอคำนวณตัวชี้วัด',score:0};
    const trend=e20>e50?'BULLISH':e20<e50?'BEARISH':'SIDEWAYS';
    const range=candles.slice(-20,-1), high=Math.max(...range.map(x=>x.high)),low=Math.min(...range.map(x=>x.low));
    const bullBreak=last.close>high,bearBreak=last.close<low;
    let score=50, direction='WAIT', reasons=[];
    if(trend==='BULLISH'){score+=15;reasons.push('EMA20 อยู่เหนือ EMA50');}
    if(trend==='BEARISH'){score+=15;reasons.push('EMA20 อยู่ใต้ EMA50');}
    if(r>=52&&r<=68&&trend==='BULLISH'){score+=10;reasons.push('RSI สนับสนุนโมเมนตัมขาขึ้น');}
    if(r<=48&&r>=32&&trend==='BEARISH'){score+=10;reasons.push('RSI สนับสนุนโมเมนตัมขาลง');}
    if(bullBreak&&trend==='BULLISH'){score+=15;direction='BUY';reasons.push('ราคาปิดทะลุกรอบสูง 20 แท่ง');}
    if(bearBreak&&trend==='BEARISH'){score+=15;direction='SELL';reasons.push('ราคาปิดหลุดกรอบต่ำ 20 แท่ง');}
    if(r>70||r<30){score-=15;reasons.push('RSI เข้าเขตสุดโต่ง ลดคะแนนสัญญาณ');}
    score=clamp(score,0,100);
    if(score<70)direction='WAIT';
    const entry=last.close, slDistance=a*1.5;
    const stopLoss=direction==='BUY'?entry-slDistance:direction==='SELL'?entry+slDistance:null;
    const takeProfit=direction==='BUY'?entry+slDistance*2:direction==='SELL'?entry-slDistance*2:null;
    return {symbol,timeframe,status:'OK',decision:direction,trend,score,entry,stopLoss,takeProfit,rr:direction==='WAIT'?null:2,rsi:r,ema20:e20,ema50:e50,atr:a,updatedAt:new Date().toISOString(),reasons};
  }
  function riskCheck({capital=10,riskPct=.25,dailyLossPct=0,entry,stopLoss,contractSize=1,tickValue=null,minQty=0,qtyStep=0}){
    const riskAmount=capital*riskPct/100, dailyLimit=capital*1.5/100;
    if(!(capital>0)||!(riskPct>0)||riskPct>.5)return {allowed:false,reason:'เงินทุนหรือเปอร์เซ็นต์ความเสี่ยงไม่ผ่านเกณฑ์'};
    if(dailyLossPct>=1.5)return {allowed:false,reason:'ถึง Daily Loss Limit 1.5% แล้ว'};
    if(!Number.isFinite(entry)||!Number.isFinite(stopLoss)||entry===stopLoss)return {allowed:false,reason:'ไม่มี Entry/Stop Loss ที่ถูกต้อง'};
    if(!Number.isFinite(contractSize)||contractSize<=0)return {allowed:false,reason:'ไม่มี Contract Size ที่ยืนยันจากโบรกเกอร์'};
    const distance=Math.abs(entry-stopLoss); const rawQty=riskAmount/(distance*contractSize);
    const qty=qtyStep>0?Math.floor(rawQty/qtyStep)*qtyStep:rawQty;
    if(!Number.isFinite(qty)||qty<minQty||qty<=0)return {allowed:false,reason:'ขนาดออเดอร์ต่ำกว่าขั้นต่ำหรือคำนวณไม่ได้ — ปฏิเสธการเข้าเทรด',riskAmount,rawQty};
    const actualRisk=distance*contractSize*qty;
    if(actualRisk>riskAmount+1e-8)return {allowed:false,reason:'ความเสี่ยงจริงเกินวงเงินที่กำหนด',riskAmount,actualRisk};
    return {allowed:true,riskAmount,dailyLossLimit:dailyLimit,quantity:qty,actualRisk,reason:'ผ่านเฉพาะการตรวจคำนวณเบื้องต้น'};
  }
  const api={ema,rsi,atr,analyze,riskCheck};
  if(typeof module!=='undefined'&&module.exports)module.exports=api; else root.ApexEngine=api;
})(typeof self!=='undefined'?self:globalThis);
