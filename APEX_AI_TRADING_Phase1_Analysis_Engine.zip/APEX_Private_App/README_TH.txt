APEX AI TRADING — PHASE 1 ANALYSIS ENGINE
รุ่น: 0.2 | Mobile-first PWA | Thai UI | Paper / Analysis only

สิ่งที่เพิ่มใน Phase 1
- analysis-engine.js: EMA20/EMA50, RSI14, ATR14 และตัวประเมินแนวโน้ม/กรอบราคา
- สร้างผลลัพธ์ BUY/SELL/WAIT พร้อมคะแนน เหตุผล Entry/SL/TP และ RR เบื้องต้น
- riskCheck(): จำกัด Risk ต่อรายการไม่เกิน 0.5%, ค่าเริ่มต้นที่ตั้งใจใช้ 0.25%, Daily Loss Limit 1.5% และปฏิเสธเมื่อข้อมูล Contract Size/ขนาดขั้นต่ำไม่ครบ
- engine.test.js: ชุดทดสอบพื้นฐาน (ต้องมี Node.js เพื่อรัน)
- ยังคงหน้าจอ PWA และตัวแสดงราคา BTC/XAU อ้างอิงจากรุ่นก่อน

ข้อจำกัดที่ต้องเข้าใจ
1) Engine นี้เป็นระบบกฎเชิงเทคนิค (deterministic rules) ไม่ใช่โมเดล Machine Learning ที่ฝึกแล้ว และคะแนนไม่ใช่ความน่าจะเป็นของกำไร
2) สัญญาณวิเคราะห์จะต้องใช้ OHLC candles ที่ถูกต้องอย่างน้อย 30 แท่ง; รุ่น UI นี้ยังไม่ได้เชื่อม candle feed ทุก timeframe เข้าหน้าจอ
3) BTCUSDT จาก Binance Spot ไม่เท่ากับ BTCUSD ของโบรกเกอร์ MT5
4) ราคาทองจาก Gold-API เป็นราคาอ้างอิง ไม่ใช่ Bid/Ask หรือแท่ง XAUUSD ของบัญชี MT5
5) ห้ามใช้ riskCheck กับเงินจริงจนกว่าจะยืนยัน Contract Size, Tick Value, Lot Step, Minimum Lot และสกุลเงินบัญชีกับโบรกเกอร์ได้ครบ
6) ยังไม่มี SMC/ICT, ข่าวเศรษฐกิจ, Open Interest, Funding Rate, Liquidation, backtesting, Telegram backend หรือ MT5 bridge ในรุ่นนี้
7) ไม่มีการส่งคำสั่งซื้อขายจริง และไม่มีการทำงานเบื้องหลัง 24 ชั่วโมงเมื่อปิดเบราว์เซอร์

การทดสอบ Engine (บนคอมพิวเตอร์ที่มี Node.js)
เปิด terminal ในโฟลเดอร์นี้ แล้วรัน: node engine.test.js

ติดตั้งเป็นไอคอนบน Android
1. ต้องเผยแพร่โฟลเดอร์นี้บน HTTPS hosting ที่เป็นส่วนตัว/ควบคุมสิทธิ์ได้
2. เปิด URL ด้วย Chrome บน Android
3. เมนู ⋮ > Install app หรือ Add to Home screen
4. เปิดแอปและตรวจสอบการเชื่อมต่ออินเทอร์เน็ต
การเปิด index.html จาก ZIP โดยตรงไม่รองรับการติดตั้ง PWA เต็มรูปแบบ

ขั้นตอนถัดไปที่จำเป็น
- เชื่อม OHLC candles ของ BTC หลาย timeframe และ feed XAUUSD จาก MT5 ที่รันบนเครื่อง/เซิร์ฟเวอร์
- เพิ่ม backend ที่มี authentication, secret storage และ scheduler สำหรับ Telegram
- ทำ backtest และ paper trading พร้อมบันทึกผล ก่อนพิจารณาเงินจริง

ห้ามส่งรหัสผ่าน MT5, API secret หรือ Telegram token ในแชตหรือใส่ไว้ในไฟล์หน้าเว็บ
