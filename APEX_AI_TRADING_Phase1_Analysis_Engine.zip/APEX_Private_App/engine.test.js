const assert=require('node:assert/strict');
const E=require('./analysis-engine.js');
const candles=Array.from({length:80},(_,i)=>({open:100+i,high:102+i,low:99+i,close:101+i}));
assert.equal(typeof E.ema(candles.map(x=>x.close),20),'number');
assert.equal(E.analyze(candles).status,'OK');
assert.equal(E.riskCheck({capital:10,riskPct:.25,entry:100,stopLoss:99,contractSize:1,minQty:1}).allowed,false);
assert.equal(E.riskCheck({capital:10,riskPct:.6,entry:100,stopLoss:99,contractSize:1,minQty:0}).allowed,false);
console.log('APEX engine tests: PASS');
